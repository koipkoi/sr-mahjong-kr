#pragma once

extern const ExpressionFunctionMap mipsExpressionFunctions;
