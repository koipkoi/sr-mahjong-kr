#pragma once
#include "Core/Assembler.h"

int runFromCommandLine(const StringList& arguments, ArmipsArguments settings = {});
